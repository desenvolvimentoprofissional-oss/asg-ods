# Tooling, dependências e instalação — 3baf58e

Revisão avaliada: `3baf58e04238ca61a386a03e39e0932de430693a`, comparada a `9a126c65ba902e19b31bc695be0ccc172df7167f`. Escopo: `package.json`, `package-lock.json`, `bun.lock`, `eslint.config.js`, scripts npm e compatibilidade do novo lint. Nenhuma fonte, configuração, teste ou lockfile do checkout foi alterado por este auditor. O diretório não versionado `documentacao/`, existente antes das verificações, foi preservado.

## Achado confirmado

### T-P1 — Alta para instalação/validação: lockfile npm não contém as novas dependências de lint

**Estado: aberto, introduzido nesta revisão.** `package.json:33`, `:42`, `:43` e `:48` adicionam `@eslint/js`, `eslint`, `eslint-plugin-react-hooks` e `typescript-eslint`. Entretanto, `package-lock.json` não recebeu alteração em relação a `9a126c6`; a lista de desenvolvimento em `package-lock.json:23` e a árvore `packages` não contêm os quatro pacotes nem suas transitivas.

O primeiro teste do auditor principal falhou por `ENOENT` no cache local em `/home/agent/.npm`, que é um problema do ambiente e não comprova a inconsistência do lock. Depois de fornecer cache gravável explícito, o teste de `npm ci --ignore-scripts --dry-run` falhou com **EUSAGE** e mensagem de manifesto/lock fora de sincronia, enumerando nominalmente os quatro pacotes novos e suas transitivas como ausentes. Evidências: `npm-ci-validation.log` (erro ambiental inicial) e `npm-ci-clean-cache.log` (falha concreta de sincronia).

Consequência: o fluxo npm de instalação com lockfile não consegue concluir em um checkout limpo. O novo `bun.lock` não é utilizado por `npm ci`, e a existência de `node_modules` já preparado não demonstra instalação repetível a partir do lock npm. Isso bloqueia a preparação e os controles pelo fluxo npm; **não é vulnerabilidade de runtime causada pelo ESLint nem evidência de falha funcional do servidor em execução**.

Correção indicada para o fluxo npm: regenerar e versionar `package-lock.json` com o manifesto atual, preservando a verificação normal de integridade, e repetir `npm ci` em diretório limpo. Se o projeto adotar Bun como único gerenciador, essa escolha precisará abranger as instruções e a configuração de instalação usadas pelo ambiente; o commit atual ainda mantém os scripts e o lock npm.

## Novo lint: validado sem alterar o checkout

`package.json:20` agora define `eslint . && tsc --noEmit && tsx scripts/check-metrics.ts`. O ESLint executa primeiro, seguido por tipos e métricas. Não executei esse wrapper neste subescopo porque a última etapa regrava um relatório versionado. O auditor principal executou as etapas restantes separadamente: TypeScript passou e a medição atual retornou 91 arquivos, 485 membros executáveis e zero erros. Assim, as etapas do pipeline foram verificadas sem reescrever o relatório versionado; isso não elimina o bloqueio da instalação npm a partir do lock.

A configuração adicionada usa os conjuntos recomendados de JavaScript, TypeScript e React Hooks; aplica `no-explicit-any` como erro e permite prefixo `_` para argumentos e variáveis não usados. Os ignores abrangem dist, build, dependências, coverage e `.aistudio`. O arquivo foi copiado byte a byte para um ambiente de ferramentas isolado em `/tmp/asg-ods-3baf58e-eslint-probe`. O SHA-256 das duas configurações é idêntico: `57c26ff1f3c90fa858b9ba04283de8ca1dcfeb55ed36ffd0f417ce52622f652f`.

Instalei nesse ambiente somente a stack de lint com as versões diretas exatas registradas no Bun lock e TypeScript 5.8.3, usando npm, cache próprio em `/tmp`, scripts de instalação desabilitados e integridade normal. Essa instalação isolada terminou com sucesso, sem editar as declarações de dependência do projeto. Ela não representa uma instalação congelada da árvore inteira do Bun lock.

Comando executado a partir de `/workspace/asg-ods`:

```text
/tmp/asg-ods-3baf58e-eslint-probe/node_modules/.bin/eslint --config /tmp/asg-ods-3baf58e-eslint-probe/eslint.config.js --format json .
```

Resultado: **exit 0; 91 arquivos; zero erros e zero avisos**. Evidências: `eslint-isolated.json` e `eslint-isolated-stderr.log`, este último vazio. Não foi confirmado erro no código alcançado pelo novo linter.

## Versões, peers e os dois locks

| Pacote | Versão no Bun lock | Compatibilidade relevante |
|---|---|---|
| `eslint` | 10.12.0 | Node `^20.19.0 || ^22.13.0 || >=24`; peer opcional `jiti`. |
| `@eslint/js` | 10.0.1 | Peer ESLint `^10.0.0`. |
| `eslint-plugin-react-hooks` | 7.1.1 | Peer inclui ESLint `^10.0.0`; Node >=18. |
| `typescript-eslint` | 8.71.2 | Peers ESLint 8.57/9/10 e TypeScript >=4.8.4 <6.1.0. |
| `typescript` | 5.8.3 | Versão registrada nos dois locks e aceita pelo TypeScript ESLint. |

Os peers dessa stack são compatíveis entre si. Node 24.19.0, utilizado no probe, e o mínimo declarado Node 22.18.0 satisfazem os requisitos do novo ESLint. Não encontrei incompatibilidade de peers nas dependências diretas adicionadas.

`bun.lock` possui versão de formato 2 e seu workspace corresponde exatamente às listas atuais de dependências e devDependencies do manifesto. Todos os pacotes diretos preexistentes têm a mesma versão resolvida nos dois locks; os quatro pacotes de lint só aparecem no Bun lock. As diferenças antigas de classificação de Tailwind/plugin React e o pacote Firebase adicional no workspace npm já existiam antes deste commit e não são a causa nova apresentada como achado.

Bun não está instalado no PATH deste ambiente. Portanto, `bun install --frozen-lockfile` não foi executado e a validação do Bun lock neste subescopo foi estrutural e de versões, não uma instalação comprovada. O manifesto não declara `packageManager` nem uma versão de Bun. Não foi encontrada configuração de CI versionada que altere explicitamente o instalador do projeto para Bun.

Comparação reproduzível dos manifests, ausência dos quatro pacotes no lock npm e peers registrados: `tooling-lock-comparison.json`.
