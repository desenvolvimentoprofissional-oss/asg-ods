# Revisão independente de segurança — 3baf58e

Commit: `3baf58e04238ca61a386a03e39e0932de430693a`. Base: `9a126c65ba902e19b31bc695be0ccc172df7167f`. Data: 13/10/2026. Código e árvore local inspecionados; `npm audit --omit=dev` executado sem instalação. Nenhuma alteração de fontes/testes/locks/docs da aplicação ou escrita no banco/produção. `documentacao/` já estava não versionado ao iniciar esta revisão e foi preservado.

## Parecer

**Não identifiquei bloqueador alto/crítico de segurança alcançável no código próprio do fluxo público. Há uma redução concreta de defesa em recurso externo: o loader VLibras perdeu SRI.** Isso merece tratamento específico, mas não comprova script comprometido, vazamento ou exploração produtiva.

O backend não sofreu mudança funcional: único endpoint de cadastro público, Zod estrito, IDs/caminhos determinados pelo servidor, cofre AES-256-GCM/HMAC e gravação conjunta por transação. Não há endpoint público de leitura do cofre/leads ou operação administrativa aberta. Regras versionadas continuam deny-all cliente. Produção serve `dist`; o navegador usa `createRoot`/`BrowserRouter`, sem SSR/RSC. A inspeção não encontrou novo sink de HTML/código a partir da entrada do usuário.

## Achado novo: VLibras sem integridade — prioridade preventiva média

**Evidência:** o diff remove `VLIBRAS_SRI_HASH` e `script.integrity`. Em `src/components/accessibility/VLibrasWidget.tsx:11–13,29–37`, o script é baixado de `https://vlibras.gov.br/app/vlibras-plugin.js`, sem verificação dos bytes. `data-version='7.12.2'` apenas adiciona um atributo: não altera o URL e não fixa conteúdo/versão. `crossOrigin='anonymous'` não substitui SRI.

O script externo executa no contexto da página, inclusive na rota do formulário. A aplicação passa a confiar em qualquer conteúdo entregue por aquele URL HTTPS permitido pela CSP. Uma alteração inesperada do fornecedor já não será bloqueada por divergência de hash. A exploração maliciosa depende de comprometimento/alteração da entrega externa; **não observei essa condição**. Também não implica que segredos do backend estejam acessíveis ao script.

Recomendação: definir como a aplicação aprova e verifica versões desse recurso, usando artefato/versionamento estável ou atualização de integridade compatível com o fornecedor. Não reinstalar cegamente um hash antigo de bytes diferentes. A classificação descreve perda de controle preventivo, não CVSS de uma brecha explorada.

O SRI dos assets locais de build é um mecanismo separado: `scripts/inject-sri.ts` permanece no comando de build. Esta revisão do código não substitui a recomposição dos hashes do novo build feita pela validação principal.

## Links, CSP e superfícies alteradas

- `SignatoryCard.tsx:10–14` e `Footer.tsx:29–45` usam destinos HTTPS fixos de `constants/chancela.ts` e `constants/footer.ts`, com `target='_blank'` e `rel='noopener noreferrer'`. Não identifiquei entrada do usuário chegando ao href, `javascript:` ou open redirect criado pelas mudanças. Os novos anchors de metodologia selecionam IDs de página; o hash não é inserido como HTML.
- `securityHeaders.ts` acrescentou três hashes de estilo e mudou uma anotação TypeScript de `setHeader`. A alteração não ampliou `script-src`, não ativou unsafe-eval/unsafe-inline em scripts produtivos e não removeu HSTS/nosniff/policies. `firebase.json` não mudou; diferenças de permissões de estilos entre publicação Firebase Hosting e Express podem afetar o widget, mas não demonstram uma brecha por si.
- Novos ESLint/plugins, `bun.lock` e mudanças de exportação/métricas são ferramentas de desenvolvimento. Dependências produtivas declaradas e o lockfile npm ficaram iguais. A compatibilidade dos gerenciadores e instalação congelada é tema de reprodução do ambiente, não vulnerabilidade produtiva automaticamente.

## Dependências e aplicabilidade

Audit atual: **duas entradas altas, zero críticas**, React Router e seu wrapper React Router DOM, na mesma cadeia. JSON: `npm-audit-production.json`. Árvore local confirma `react-router=7.13.2`, `vite=6.4.1` e `@grpc/grpc-js=1.14.6`. Não tratei a severidade máxima do pacote como severidade demonstrada da aplicação.

| Grupo de avisos | Contexto da aplicação |
| --- | --- |
| Turbo-stream, SSR hydration, RSC, __manifest, single-fetch, actions/document requests | Não há handler/framework React Router no servidor, SSR hydration, RSC ou actions de roteador. Não foi identificado caminho correspondente. |
| Open redirect em Link/useNavigate (`GHSA-wrjc-x8rr-h8h6`), redirect `//` (`GHSA-2j2x-hqr9-3h42`) | Nem todo aviso é SSR/RSC. Entretanto, os destinos efetivos são constantes locais e os novos URLs externos também são fixos; não há retorno/URL controlado pelo usuário alimentando redirects. Nenhum vetor foi demonstrado. |
| Route matching (`GHSA-chx6-hx7r-mcp5`) | Rotas poucas e estáticas no cliente; não se demonstrou DoS remoto do servidor por esse roteador. |
| Vite/build/transitivas | Vite só é importado no modo de desenvolvimento. Não é middleware no ramo produtivo. Entradas específicas de build/source maps não são a entrada do cadastro público. Não foram usados avisos desses contextos como prova de comprometimento do site. |

Disposição: existem advisories reais nas versões; não foi demonstrada exploração aplicável aos fluxos produtivos inspecionados. A atualização continua matéria de manutenção contextualizada, sem inventar múltiplos incidentes a partir da mesma cadeia.

## Condições operacionais preservadas

Mantêm-se as ressalvas anteriores: `NODE_ENV='production'` é configuração externa exigida para usar dist/CSP produtiva; trust proxy e limite por processo dependem da cadeia real; `(default)` não vence banco nomeado do arquivo; recuperação de índice sem `leadId` é condição específica de legado; rotação/entropia das chaves e escala dos buckets dependem da operação. Nenhuma dessas condições foi demonstrada como falha da publicação nesta revisão.

As capturas mostram segredos cadastrados no AI Studio e registros Firestore, portanto não há base para alegar falta de chaves na aplicação. Não observei o IAM publicado, regras efetivas, SHA implantado ou migração/concorrência real. Os resultados externos informados são evidências complementares de seus escopos, sem certificar todos os fluxos do código. Problemas de teclado/conteúdo/acessibilidade devem manter a categoria funcional adequada, sem serem rebatizados como vulnerabilidades de segurança.
