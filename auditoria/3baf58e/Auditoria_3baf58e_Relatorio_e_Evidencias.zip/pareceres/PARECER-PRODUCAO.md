# Reauditoria — ASG-ODS, revisão 3baf58e

**Data:** 13/10/2026, America/Sao_Paulo. **Repositório:** `desenvolvimentoprofissional-oss/asg-ods`. **Commit:** `3baf58e04238ca61a386a03e39e0932de430693a`. **Base anterior:** `9a126c65ba902e19b31bc695be0ccc172df7167f`. O HEAD da main remota foi conferido no início e no encerramento das verificações.

## Parecer e nota

**Nota técnica geral: 8,5/10. Não foi demonstrada vulnerabilidade alta/crítica alcançável no código próprio. A publicação por instalação limpa via npm permanece bloqueada pelo lockfile desatualizado.**

O código compilou, passou no TypeScript, nos 31 testes existentes, no novo ESLint e nas métricas. O runtime de produção local também passou nas verificações de rotas, cabeçalhos, SRI dos assets e rejeição de JSON inválido/excessivo. Esses resultados foram obtidos com a árvore de dependências já preparada para a aplicação e ferramentas de lint isoladas; eles não demonstram que uma instalação limpa do manifesto atual funciona com o lock npm.

Antes de uma publicação que use npm, o manifesto e o lock precisam voltar a corresponder e a instalação limpa deve passar. A proteção de integridade retirada do script VLibras e o foco invisível do carrossel também merecem correção. O primeiro é perda de defesa preventiva, e o segundo é falha de navegação por teclado; não foram classificados como ataques ou vazamentos.

Se a implantação utiliza Bun, a falha de npm não prova que esse processo falhará: o novo Bun lock é estruturalmente coerente, mas uma instalação congelada com Bun não foi executada nesta sessão. Portanto este parecer não certifica esse caminho de entrega nem o ambiente publicado.

## Achados confirmados

| ID | Categoria e prioridade | Evidência atual | Consequência e encaminhamento |
| --- | --- | --- | --- |
| R01 | Instalação/entrega: bloqueia o fluxo npm | `package.json` ganhou quatro dependências ESLint; `package-lock.json` permanece igual à base e não as contém. A validação de `npm ci`, com cache gravável, retorna `EUSAGE`; a variante `--omit=dev` também falha. | Corrigir/versionar o lock npm e repetir a instalação limpa. O Bun lock não é consumido pelo npm. Não é falha de runtime ou brecha causada pelo ESLint. |
| R02 | Segurança preventiva: média | `VLibrasWidget.tsx` removeu `VLIBRAS_SRI_HASH` e `script.integrity`. A tag real usa URL mutável e `data-version="7.12.2"`, que não verifica os bytes. | Uma alteração inesperada do arquivo externo deixa de ser rejeitada por divergência de hash. Definir aprovação/versionamento e integridade compatíveis com o fornecedor; não recolocar cegamente um hash antigo. Nenhum comprometimento externo foi observado. |
| R03 | Acessibilidade/uso: média | Após Tab chegar ao primeiro cartão de signatário, o loop reposiciona o carrossel em cerca de 150 ms. O cartão continua focado, mas passa para x=-1825, fora do contêiner x=76..1204. | O usuário de teclado perde a indicação visível do foco. O loop precisa preservar a visibilidade e a posição do elemento focado. Os novos links são legítimos, mas devem funcionar também pelo teclado. |
| R04 | Configuração: baixa e condicional | A CSP do Express ganhou três hashes SHA-256 de `style-src`; `firebase.json` não recebeu esses hashes. As demais diretivas produtivas coincidem. | Um estilo que dependa de um desses hashes pode ser autorizado pelo Express e recusado no HTML do Hosting. Não foi demonstrado que o CSS real do widget exija esses hashes nem que o domínio publicado tenha quebra. Conferir a política do caminho efetivamente usado. |

O primeiro erro de npm observado foi `ENOENT` no cache padrão do ambiente. Ele não foi atribuído ao projeto. A nova tentativa com cache próprio isolou e comprovou a divergência de lock por `EUSAGE`. Foi usado `--dry-run` para validar o instalador sem remover a árvore existente; a checagem de sincronia impede a instalação antes dessa etapa. Logs: `npm-ci-clean-cache.log` e `npm-ci-production-validation.log`.

R02 é uma mudança concreta na verificação do primeiro arquivo JavaScript externo. TLS e a lista de origens da CSP permanecem ativos, mas não fixam os bytes desse recurso. O SRI dos assets locais do Vite é separado e continua correto. O script oficial não pôde ser carregado neste ambiente por falha de túnel/403; isso foi registrado como limite de rede, não como defeito da produção.

R03 foi reproduzido em Chromium usando foco por teclado e medição do elemento antes/depois do reposicionamento. O foco de alto contraste foi retestado pelo teclado: o contorno amarelo sólido de 3 px aparece corretamente. Um resultado anterior obtido por foco programático não foi usado como achado.

## Alterações verificadas sem regressão identificada

- As três âncoras novas da metodologia encontram os IDs corretos; a navegação repetida para o mesmo hash e o acesso direto ao módulo 6 funcionaram.
- Os cartões de signatários e o rodapé usam destinos HTTPS constantes, com `noopener noreferrer`. As redes sociais do rodapé agora reutilizam os mesmos destinos da barra superior.
- Os controles de fonte/contraste em rem acompanham a escala: 30 px passam a 36 px e 11 px a 13,2 px na escala 1,2. A chamada de interesse permaneceu dentro do hero, sem overflow horizontal, nos tamanhos testados de 320, 390, 640 e 1280 px.
- O modal de privacidade abriu, fechou com Escape e devolveu o foco ao acionador nos cenários verificados.
- A anotação TypeScript mais precisa de `setHeader` preservou o comportamento de cookies escalares, listas, arrays congelados, SameSite existente e cabeçalhos numéricos.
- API, schema Zod, cofre AES-GCM/HMAC, transações, seleção Firebase e regras Firestore permanecem iguais à revisão anterior. Não foi adicionada rota de leitura dos leads/cofre nem entrada controlada pelo usuário em destinos externos.
- As duas expressões regulares alteradas no analisador de métricas mantêm o significado. As métricas reais retornaram 91 arquivos, 485 executáveis e zero erros. `CODIGOFONTE.txt` corresponde à saída dos 110 arquivos selecionados nessa versão.

## Verificações e evidências

| Verificação | Resultado | Evidência |
| --- | --- | --- |
| TypeScript | Passou | `typecheck.log` |
| Build Vite + injeção SRI | Passou | `build.log` |
| Testes existentes | 31 passaram; 0 falharam; quatro arquivos | `tests.log` |
| ESLint | 91 arquivos; zero erros e avisos | `eslint-isolated.json`, `tooling.md` |
| Métricas | 91 arquivos; 485 executáveis; zero erros | `metrics-current.json`, `metrics-ledger.json` |
| Instalação npm com lock | Falhou por `EUSAGE`, inclusive omitindo devDependencies | `npm-ci-clean-cache.log`, `npm-ci-production-validation.log` |
| Runtime produtivo local | Iniciou com Node 24.19.0 e `NODE_ENV=production` | `server.log` |
| HTTP, fonte interna e assets | 18 checks passaram; dois hashes SRI recalculados e conferidos | `runtime-smoke.json` |
| Navegador | Âncoras, URLs, reflow, fonte e modal passaram; foco do carrossel falhou | `frontend-evidence.json`, `card-focus-after-balance.png`, `high-contrast-keyboard.json` |
| Cabeçalhos e cookies | Sondagens passaram; divergência CSP de estilos identificada | `backend-evidence.json`, `backend.md` |
| VLibras | Tag sem SRI confirmada; recurso oficial não carregou por bloqueio de rede do ambiente | `vlibras.md`, `vlibras-evidence/` |
| Dependências produtivas | Duas entradas altas da mesma cadeia React Router; zero críticas | `npm-audit-production.json`, `security-independent.md` |

O ESLint foi executado com uma cópia byte a byte da configuração atual e as versões diretas registradas no Bun lock, instaladas fora do checkout. O wrapper `npm run lint` não foi executado porque sua última etapa regrava um relatório versionado; ESLint, TypeScript e métricas foram conferidos separadamente. Isso preservou os arquivos do autor e não ocultou a falha de instalação.

Os advisories de React Router não foram descartados apenas porque a aplicação é SPA: também foram considerados os de redirects e matching no cliente. SSR/RSC/framework handlers não existem neste servidor, e os destinos de navegação relevantes são constantes. Não foi demonstrado vetor explorável nos fluxos atuais, nem foram contadas duas entradas da mesma cadeia como dois incidentes produtivos.

## Critérios da nota

São os mesmos pesos da avaliação anterior. A nota é julgamento técnico do código e da entrega verificável, não certificação de segurança nem pontuação dos scanners.

| Critério | Nota | Peso | Fundamentação |
| --- | --- | --- | --- |
| Segurança do código próprio | 8,5/10 | 60% | Controles de servidor e dados preservados, sem vetor alto/crítico demonstrado; integridade do primeiro script remoto VLibras retirada. |
| Integridade e comportamento | 8,5/10 | 25% | Melhorias de links, âncoras e fonte verificadas; novo foco invisível no carrossel reproduzido. |
| Verificação e cobertura | 7/10 | 15% | Lint novo e checks locais passaram; instalação limpa npm bloqueada e transações/IAM publicados não executados. |

Média ponderada: 8,275; apresentação na mesma escala de meio ponto: **8,5/10**. A redução em relação a 9/10 decorre dos achados novos, não dos avisos de scanners nem da ausência de chaves neste ambiente.

## Limites e preservação

Não foram solicitadas/lidas chaves privadas ou credenciais reais; não houve cadastro/gravação em Firestore de produção nem teste de concorrência real no banco publicado. Portanto persistência real, IAM, regras efetivas e o SHA do serviço implantado continuam fora do resultado comprovado. As capturas anteriormente fornecidas permanecem evidência de configuração e registros existentes; a falta de acesso do auditor não foi transformada em falha do usuário.

Permanecem as observações anteriores de UX/acessibilidade e as condições operacionais já contextualizadas. Esta revisão não atribui conformidade integral WCAG ou conclusão jurídica. Os excelentes resultados externos fornecidos pelo usuário não foram reexecutados nem usados como prova de todos os fluxos internos.

A comparação cobriu os 24 arquivos alterados e os fluxos adjacentes relevantes. Fontes, testes, lockfiles e configurações não foram editados pelo auditor; a atualização local foi apenas fast-forward para o código disponibilizado no GitHub. Os artefatos desta auditoria ficam fora do checkout. Os documentos anteriores, suas fontes e a branch de entrega foram preservados; seus hashes PDF/Word foram reconferidos. A documentação continua pausada.

Observações menores de ferramentas: duas referências de linha do relatório de métricas estão deslocadas em uma linha, sem números errados; o exportador agora inclui `.env.example`, enquanto a regra textual `.env.*` do AGENTS não explicita essa exceção. O arquivo atual contém placeholders, sem segredo real: isso não foi apresentado como vazamento nem impedimento produtivo.
