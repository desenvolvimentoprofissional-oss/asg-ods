# Reauditoria de frontend — 3baf58e

Commit atual: `3baf58e04238ca61a386a03e39e0932de430693a`; comparação com `9a126c65ba902e19b31bc695be0ccc172df7167f`. Verificações no Chromium 154 contra build novo de produção em `http://127.0.0.1:3011`. Fontes, testes e documentação não foram alterados. Contador de cadastro: **zero POSTs**, sem gravações no banco ou navegação aos destinos institucionais externos.

## Resultado

Foi confirmada **uma regressão de acessibilidade de severidade média**: o novo link do primeiro cartão recebe foco por teclado e, em seguida, o reposicionamento do carrossel leva esse elemento para fora da área visível. Trata-se de foco/navegação visual; não é bypass, XSS, exposição de dados ou incidente de segurança. Não foi confirmada falha de segurança nos novos URLs de cartões/rodapé ou no processamento das âncoras.

## F01 — Média, acessibilidade: foco fica na cópia invisível do cartão

**Fontes atuais:** `src/components/presentation/SignatoryCard.tsx:10` tornou o cartão um link; `src/components/presentation/SignatoriesCarousel.tsx:47` renderiza três cópias; `src/components/presentation/useSignatoriesCarousel.ts:27–33` reposiciona a rolagem; `:98–101` agenda esse reposicionamento após o evento de scroll.

**Cenário reproduzido:** em `/chancela`, partir do botão “Próximo” e pressionar Tab para entrar nos cartões. O primeiro link, CRA-SP, recebe foco com `:focus-visible=true` e `scrollLeft=0`. Inicialmente seu retângulo começa em `x=80`, dentro do container `x=76…1204`. Após 600 ms, `scrollLeft` passa a 1905; o elemento ativo continua sendo a **cópia de índice 0**, agora em `x=-1825`, inteiramente fora do container. A cópia visualmente equivalente que aparece na tela não recebe o foco.

**Impacto:** usuário de teclado perde a localização visual do link focado. O indicador de foco existe, mas está no cartão oculto pela rolagem. O comportamento é relevante aos critérios de foco visível e foco não inteiramente oculto da WCAG. O link permanece identificado no DOM; não se afirma perda de autorização ou desvio do destino.

**Relação com o baseline:** o loop já existia; os cartões eram divs sem esse alvo de tabulação. Converter as três cópias em links introduz o cenário. A correção anterior dos indicadores dos botões, A08, continua presente; esse achado trata do elemento focado sair da viewport, não da ausência de uma regra CSS de foco.

**Ação indicada:** manter o cartão focado visível durante o reposicionamento, coordenando o foco com as cópias do carrossel e os alvos de tabulação. Não foi feita correção de código.

Evidências: `frontend-evidence.json`, chaves `card_focus_immediate`/`card_focus_after_balance`; `card-focus-after-balance.png`; reprodução em `frontend-probe.py`.

## Verificações que passaram no escopo observado

| Área | Evidência observada |
| --- | --- |
| Âncoras da metodologia | Os três links do footer encontram os novos IDs e rolam para a seção correspondente. |
| Reentrada no mesmo hash | Clicar novamente “Flexibilidade de Implementação” volta à seção; alvo em `y=-0,5px` ao fim da rolagem. |
| Link direto da trilha | `/trilha#modulo-6` apresenta o módulo; posição aproximada `y=127,75px`, compatível com scroll-margin. |
| Novos destinos externos | Cinco destinos constantes HTTPS, com `target=_blank` e `rel=noopener noreferrer`, nos cartões e rodapé. Sem URLs de entrada externa processadas nesses dados. |
| Redes sociais | Footer utiliza `TOPBAR_SOCIAL_ITEMS`, unificando seus destinos com os da barra superior. |
| Toolbar em rem | A+ cresce de 30×30px/11px para 36×36px/13,2px quando a escala passa de 1 para 1,2. |
| Reflow/escala da home | Viewports 1280, 640, 390 e 320px, fonte 1,2; largura de scroll igual à viewport e CTA dentro do retângulo do hero. |
| Foco em alto contraste | Com Tab verdadeiro, cartão tem outline **amarelo sólido de 3px**; nenhuma falha global de foco HC foi confirmada. |
| Diálogo | Modal nativo abre; Escape fecha e devolve foco ao botão de privacidade. |

Referências: `PublicLayout.tsx:18–28`; `constants/footer.ts:3–20`; IDs em `MetodologiaPillars.tsx:20`, `MetodologiaFormats.tsx:24`, `MetodologiaImplementation.tsx:24`; `constants/chancela.ts:14`, `:26`, `:37`, `:51`, `:66`; `SignatoryCard.tsx:11–18`; `Footer.tsx:29–44` e `:71–77`; `TopBarFontSizeButtons.tsx:13–17`.

## Observação visual delimitada

No hit-test adicional de home a 320px com fonte 1,2, a base do CTA sobrepõe a faixa de logos em aproximadamente **24,25px**. O centro do botão continua recebendo o hit-test corretamente. Fontes: hero com altura fixa em `HomeHero.tsx:93` e faixa absoluta em `HomeLogosBar.tsx:33–34`. A mudança diminui a fonte e altera as margens do hero; este teste não estabelece que a sobreposição tenha sido introduzida pelo commit. Registra-se como observação visual de baixa prioridade, sem classificá-la como nova regressão de segurança ou bloqueio de cadastro.

Evidências: `hero-hit-test.json`, `home-320-hero-120.png`. Reflow em viewport estreita e escala 1,2 não substitui teste completo de zoom nativo do navegador.

## Contexto preservado e limites

Os fluxos do formulário, normalização de telefone e nome acessível de retorno não foram alterados por este diff; as correções já registradas de A03/A15/A17/A18 não são reabertas. A16 continua separado entre títulos e gerenciamento de foco. O autoplay/atalhos anteriormente descritos mantêm seu contexto; F01 é o novo cenário de links focados no loop.

O valor `high_contrast_card_focus` do primeiro JSON provém de foco programático após click do mouse, sem estabelecer `:focus-visible`; seu outline não sólido **não é um achado**. A verificação correta está em `high-contrast-keyboard.json`, com `focusVisible=true` e outline sólido de 3px.

Não foram coletados elementos STYLE inline no DOM das páginas percorridas (`inline_styles=[]`). Portanto este probe não demonstra quebra funcional causada pela diferença dos três hashes de style-src entre Express e Firebase Hosting, discutida no relatório backend. A remoção de SRI no carregador VLibras foi observada no diff e comunicada ao agente principal para a análise paralela de integridade; não foi demonstrada exploração por esse caminho.

Sem POST/cadastro, testes de carga, validação de titularidade/disponibilidade dos destinos externos, leitores de tela ou browsers além de Chromium. Artefatos e screenshots ficam fora do checkout; o relatório documentacional anterior permaneceu intacto.
