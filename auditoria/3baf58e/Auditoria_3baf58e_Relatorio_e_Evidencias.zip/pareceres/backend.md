# Reauditoria backend e cabeçalhos — 3baf58e

Revisão: `3baf58e04238ca61a386a03e39e0932de430693a`. Base: `9a126c65ba902e19b31bc695be0ccc172df7167f`.

**Não foi identificada regressão backend de severidade alta/crítica ou impedimento concreto de segurança na API, Firestore ou criptografia.** O código dessas áreas permanece igual à base. A mudança dos cabeçalhos amplia três hashes de estilo específicos; os testes locais confirmaram os demais cabeçalhos e o tratamento de cookies. Há uma diferença confirmada entre as políticas CSP do Express e do Firebase Hosting, descrita abaixo com seu alcance.

## 1. Alterações e alcance

No escopo backend, apenas `src/server/securityHeaders.ts` mudou: linhas12-14 acrescentam três hashes SHA-256 em `style-src`;87 substitui o tipo TypeScript `any` do valor de `setHeader` por `number | string | readonly string[]`.

Os hashes são permissões para conteúdos específicos de elementos de estilo. Nenhuma origem nova foi adicionada. `script-src`, `connect-src`, `frame-ancestors`, `object-src`, demais diretivas e política de desenvolvimento permanecem iguais. A mudança mantém `default-src 'none'`, `object-src 'none'` e a ausência de `unsafe-inline`/`unsafe-eval` em `script-src` produtivo. A permissão já existente de `style-src-attr 'unsafe-inline'` não foi alterada.

A alteração do tipo de `setHeader` não muda a função JavaScript executada. Foram testados no Express real: cookie escalar, lista de cookies, array congelado (equivalente runtime ao tipo readonly), cookie com SameSite=Strict, cookie com SameSite=None e cabeçalho numérico comum. Cookies receberam Secure/HttpOnly e SameSite=Lax quando ausentes; valores Strict/None existentes foram mantidos e o cabeçalho numérico passou normalmente. Não foi constatada regressão desse tratamento.

## 2. Diferença CSP entre caminhos de publicação

**Achado confirmado de configuração declarada, prioridade baixa; efeito funcional dependente do caminho servido.**

Referências: `src/server/securityHeaders.ts:12` e `firebase.json:23`.

A comparação das diretivas mostrou que a única diferença entre a CSP produtiva do Express e a de Firebase Hosting é a ausência, no Hosting, destes três hashes:

- `sha256-K1YGCJ9Cg1Y7R6JLOf8v8m/fYMKl7z8n4H6C96EuRE4=`
- `sha256-aONVQQvH1cFuvg38jkGtM/thDaulvTnuyax++NvB8kA=`
- `sha256-8GWAUrRyaI3gREajBb5ihH3tKcnImvvB7k9KB2GodIg=`

Assim, um documento entregue pelo Express aceita elementos `<style>` com esses conteúdos, enquanto a política configurada para o HTML estático no Firebase Hosting não os autoriza por hash. A permissão de atributos de estilo não substitui a de elementos `<style>`. O arquivo Firebase entrega a página de `dist` e encaminha `/api/**` para Cloud Run; a CSP de uma resposta API não substitui a política do documento HTML.

A existência das duas políticas diferentes foi comprovada no código e em cabeçalho HTTP do Express local. Nesta execução não se correlacionou o conteúdo dos três estilos com um elemento real da interface nem se verificou qual caminho atende o domínio publicado. Portanto não se declara quebra da interface em produção, exposição de dados ou bypass de CSP. O achado não constitui falta de acesso/credencial: é uma diferença concreta entre dois artefatos de configuração mantidos no checkout. Para uniformidade, os hashes aplicáveis podem acompanhar a política do caminho de publicação utilizado.

## 3. Cabeçalhos e cookies verificados

Um POST local com objeto inválido retornou 400/INVALID_ARGUMENT e os cabeçalhos esperados:

- HSTS `max-age=63072000; includeSubDomains; preload`;
- `X-Content-Type-Options: nosniff`;
- `Referrer-Policy: no-referrer`;
- CORP `same-origin`, COEP `credentialless`, COOP `same-origin-allow-popups`;
- Permissions-Policy restritiva e CSP produtiva com os três hashes novos;
- ausência de `X-Powered-By`.

Todos esses controles mantêm os valores da base. As sondagens de cookies ocorreram em rotas transitórias apenas na instância Express importada num processo de teste separado; essas rotas não foram escritas no código e não existem na aplicação distribuída. Seus valores são marcadores sintéticos, sem credenciais ou cookies reais.

## 4. Controles backend preservados

Foram relidos o servidor, serviço de buckets, cofre, schema e serviço cliente. O diff confirma ausência de alteração nesses arquivos, em `firestore.rules` e em `firebase.json`.

- A entrada continua sendo objeto Zod estrito, com normalização de email, campos limitados e corpo JSON de 15kb. A rota pública de cadastro continua única; não foi adicionada rota de leitura/decifragem/exportação do banco.
- UUID, origem, estado e nomes de coleções continuam gerados/definidos no servidor. Referências ao banco não derivam de operadores ou caminhos arbitrários do request.
- O índice por HMAC-SHA256 normalizado e a reconstrução usando o leadId da manifestação existente permanecem iguais. Índice, cofre e bucket continuam agendados na mesma transação.
- Nome, email, telefone e observações continuam cifrados com AES-256-GCM, IV aleatório de 12 bytes e tag. Observações permanecem fora do registro operacional, que guarda `temObservacoes`.
- As respostas de validação/duplicidade/persistência/exceção continuam com status e mensagens do contrato. A sanitização limitada a 2.000 caracteres, redaction de identificadores e regras do cliente deny-by-default permanecem iguais.
- Precedência Firebase e exceção `(default)` não mudaram. Não foi inferida configuração produtiva inadequada pela ausência de acesso à plataforma.

Os pontos anteriores já descritos — teste transacional real, regras publicadas e IAM — continuam como limites de verificação desta sessão. Não são classificados como falhas de código.

## 5. Evidências e preservação

`backend-probes.mjs` e `backend-evidence.json` registram as sondagens reproduzíveis. Foi usado processo próprio com NODE_ENV=test para importar a aplicação sem listener automático, seguido da seleção da política produtiva. As requisições foram locais e não houve operação Firestore nem escrita ou POST em produção. Nenhum segredo real foi lido ou impresso.

Nenhum arquivo de fonte, dependência ou regra foi alterado. O diretório não versionado `documentacao/` já existia na fotografia inicial e foi preservado. Inventário: server.ts; src/server/leadBucketService.ts; src/server/vaultService.ts; src/server/securityHeaders.ts; src/types/leads.ts; src/api/leadsService.ts; firestore.rules; firebase.json; .firebaserc; .env.example; package.json; trechos relacionados aos cabeçalhos/cookies em tests/leads.test.ts. A remoção de SRI do script VLibras está sendo examinada no escopo frontend/supply chain e não é mudança do backend.
