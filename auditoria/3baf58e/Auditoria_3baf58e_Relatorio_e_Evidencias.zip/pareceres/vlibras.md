# VLibras e políticas CSP — revisão do commit 3baf58e

**Commit:** `3baf58e04238ca61a386a03e39e0932de430693a`. **Base:** `9a126c65ba902e19b31bc695be0ccc172df7167f`.

**Conclusão:** confirmou-se retirada do SRI do arquivo inicial do VLibras e divergência entre as políticas de estilos do Express e do Firebase Hosting. A primeira mudança remove um controle de integridade existente; a segunda tem consequência funcional condicionada ao CSS que o widget efetivamente emitir e ao caminho de publicação. Não se confirmou exploração, alteração maliciosa do serviço oficial, versão efetivamente diferente ou falha do widget na implantação pública.

## V01 — Média: retirada da verificação de integridade do script externo

**Fontes atuais:** `src/components/accessibility/VLibrasWidget.tsx:11-13,24-37`; `src/server/securityHeaders.ts:5-6`.

A versão anterior definia `VLIBRAS_SRI_HASH` e atribuía esse valor a `script.integrity`. O commit removeu a constante e a atribuição. O hash anterior é uma representação SHA-384 válida de 48 bytes; não foi possível verificar se corresponde aos bytes atualmente fornecidos pelo serviço oficial.

No build de produção local, o navegador recebeu a tag real com:

```text
src: https://vlibras.gov.br/app/vlibras-plugin.js
integrity: vazio
crossorigin: anonymous
data-version: 7.12.2
async: true
```

A URL não contém versão fixa. `data-version="7.12.2"` é metadado atribuído pelo próprio componente e não faz o navegador conferir a versão ou o conteúdo recebido. `crossorigin="anonymous"` define o modo CORS, sem comparar bytes com um hash esperado. A CSP permite scripts desse host e seus subdomínios; o hash de script que também aparece nessa diretiva não prende esse URL a um conteúdo específico, pois a permissão por host continua válida.

**Importância real para produção:** o arquivo inicial externo passa a ser aceito sem a comparação de integridade que antes existia. Mudanças nesse arquivo, inclusive atualizações legítimas do fornecedor, deixam de ser detectadas por esse controle. Um script externo carregado dessa forma executa no contexto da página, que também apresenta campos de contato. HTTPS e CSP permanecem ativos, delimitando o cenário; não há demonstração de ataque ou exposição atual desses dados.

O SRI anterior verificava esse arquivo inicial. Não se atribui ao controle antigo cobertura de todos os recursos que o widget possa carregar posteriormente. Também não houve remoção observada do mecanismo que injeta SRI nos assets próprios do build, tratado separadamente por `scripts/inject-sri.ts`.

**Orientação:** manter uma estratégia verificável para o arquivo oficial e a versão homologada, com atualização do hash a partir de bytes obtidos de fonte confiável e revisão da mudança. A disponibilidade desta sessão não permite recomendar um novo hash concreto. Se for adotado outro controle de integridade, documentar seu alcance e a decisão correspondente.

## V02 — Baixa, compatibilidade condicional: hashes de estilo só foram adicionados ao Express

**Fontes:** `src/server/securityHeaders.ts:7-16`; `firebase.json:21-23`.

A comparação estruturada das duas políticas encontrou uma única diferença: `style-src`. A política Express possui sete hashes SHA-256 de estilos inline; a configuração estática do Firebase possui os quatro anteriores. Os três exclusivos do Express são:

```text
sha256-K1YGCJ9Cg1Y7R6JLOf8v8m/fYMKl7z8n4H6C96EuRE4=
sha256-aONVQQvH1cFuvg38jkGtM/thDaulvTnuyax++NvB8kA=
sha256-8GWAUrRyaI3gREajBb5ihH3tKcnImvvB7k9KB2GodIg=
```

As demais diretivas comparadas, incluindo `script-src`, são iguais. Os novos hashes autorizam conteúdos exatos de elementos de estilo e não substituem o SRI retirado do JavaScript. Não constituem liberação geral de scripts ou de todos os estilos inline. A permissão de atributos de estilo já estava presente antes da mudança.

**Consequência alcançável sob condição:** se o widget emitir um elemento inline que dependa de um desses três hashes, o documento servido com a política Express poderá aceitá-lo e o documento servido com a política de `firebase.json` poderá bloqueá-lo. No Hosting, a política aplicável ao documento vem de sua resposta HTTP; uma resposta posterior da API no Cloud Run não acrescenta permissões àquele documento.

A divergência de configuração é comprovada. A identidade desses três estilos, sua emissão pelo plugin atual e o uso real do Hosting no deploy público não foram comprovados nesta revisão. Portanto, não se afirma que a interface em produção esteja quebrada. Recomenda-se manter as políticas correspondentes sincronizadas e conferir os hashes contra os estilos reais emitidos pela versão utilizada, quando o recurso oficial estiver acessível.

## Evidência de runtime e limite de acesso

O servidor local em `http://127.0.0.1:3011/` respondeu 200; sua CSP real é idêntica à constante de produção Express. O navegador tentou carregar o URL oficial quatro vezes, sem respostas falsas, substituições ou alteração de TLS. As tentativas falharam com `net::ERR_TUNNEL_CONNECTION_FAILED`. A biblioteca global e o wrapper do widget ficaram ausentes; a mensagem “Widget VLibras temporariamente indisponível.” apareceu.

Uma requisição somente leitura por curl ao mesmo URL recebeu HTTP 403 com `server: envoy`. Não foram recebidos bytes do script. Esses resultados descrevem o acesso desta sessão, sem atribuir a recusa ao servidor final do VLibras. Não se tentou mudar proxy, verificação TLS ou URL para contornar a restrição.

Nenhum elemento `<style>` nativo foi observado e não houve evento de violação CSP do widget, porque seu JavaScript não carregou. Isso não comprova compatibilidade dos estilos nem funcionamento da integração. Não foi possível correlacionar os três hashes novos com CSS oficial atual, identificar a versão fornecida ou comparar os bytes oficiais com o SRI anterior.

## Requisitos do projeto relacionados

- `AGENTS.MD:60`: “Nenhuma proteção de segurança poderá ser removida, desabilitada ou enfraquecida para fazer uma implementação funcionar.” O SRI era um controle existente; sua retirada precisa ser tratada no contexto desse requisito.
- `AGENTS.MD:779-794`: preservação da CSP homologada e da integração VLibras na versão 7.12.2; mudanças em decisões homologadas exigem autorização expressa e revisão correspondente.
- `AGENTS.MD:1434-1476`: o anexo registra `SEC-CSP` e `ACCESS-VLIBRAS` e prevê rastreabilidade das alterações. Não foi localizado um ADR detalhado desses itens nos arquivos de documentação versionados consultados.

Não se conclui que a mudança foi feita sem autorização, pois esta revisão não reconstituiu seu processo de aprovação. O ponto técnico demonstrado é que a constante 7.12.2, sozinha, não assegura a versão carregada e que o controle SRI foi retirado. A revisão foi somente leitura e não solicita nem executa alterações do projeto.

## Artefatos

- `vlibras-evidence/source-comparison.json`: atributos antes/depois, validade do formato SRI e diferenças entre CSPs.
- `vlibras-evidence/runtime.json`: tag real, CSP recebida, tentativas de rede, estado do widget e elementos de estilo observados.
- `vlibras-evidence/plugin.headers`: resposta HTTP 403 da requisição somente leitura.
- `vlibras-evidence/probe-vlibras.py`: script de reprodução local.

Fontes e documentação do checkout foram preservados. A pasta `documentacao/` já estava não versionada antes desta tarefa e não foi modificada.
