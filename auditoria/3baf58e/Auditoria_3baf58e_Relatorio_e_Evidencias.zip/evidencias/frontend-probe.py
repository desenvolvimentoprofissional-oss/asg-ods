import base64
import hashlib
import json
from pathlib import Path
import sys
from playwright.sync_api import sync_playwright

OUT = Path('/workspace/production-review-3baf58e')
BASE = sys.argv[1]
results = {'commit':'3baf58e04238ca61a386a03e39e0932de430693a','base':BASE,'api_posts':0}

def box_state(page, selector):
    return page.locator(selector).evaluate('''el=>{const r=el.getBoundingClientRect(),s=getComputedStyle(el);return {rect:{x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom},fontSize:s.fontSize,outline:s.outline,boxShadow:s.boxShadow,focus:el===document.activeElement,focusVisible:el.matches(':focus-visible')}}''')

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1280,'height':900})
    def count_post(req):
        if req.method=='POST' and '/api/registrar-interesse' in req.url: results['api_posts']+=1
    page.on('request',count_post)
    page.goto(BASE+'/',wait_until='domcontentloaded')
    page.locator('footer').wait_for()
    results['footer_links']=page.locator('footer a').evaluate_all("els=>els.map(el=>({text:el.textContent,aria:el.getAttribute('aria-label'),href:el.getAttribute('href'),target:el.getAttribute('target'),rel:el.getAttribute('rel')}))")
    results['anchors']=[]
    for name, target in [('Por que "Dinâmica"?','por-que-dinamica'),('Formatos de Aprendizagem','formatos-de-aprendizagem'),('Flexibilidade de Implementação','flexibilidade-de-implementacao')]:
        page.locator('footer').get_by_role('link',name=name,exact=True).click()
        page.wait_for_url('**/metodologia#'+target)
        page.wait_for_timeout(850)
        results['anchors'].append({'target':target,'url':page.url,'rect':box_state(page,'#'+target)['rect'],'scrollY':page.evaluate('scrollY')})
    page.locator('footer').get_by_role('link',name='Flexibilidade de Implementação',exact=True).click()
    page.wait_for_timeout(850)
    results['same_hash_reentry']={'url':page.url,'rect':box_state(page,'#flexibilidade-de-implementacao')['rect'],'scrollY':page.evaluate('scrollY')}
    page.goto(BASE+'/trilha#modulo-6',wait_until='domcontentloaded')
    page.locator('#modulo-6').wait_for()
    page.wait_for_timeout(850)
    results['trilha_direct_hash']={'url':page.url,'rect':box_state(page,'#modulo-6')['rect'],'scrollY':page.evaluate('scrollY')}
    page.goto(BASE+'/chancela',wait_until='domcontentloaded')
    page.get_by_role('button',name='Próximo',exact=True).wait_for()
    cards=page.locator('a[aria-label^="Acessar página oficial:"]')
    results['signatory_links']=cards.evaluate_all("els=>els.map(el=>({aria:el.getAttribute('aria-label'),href:el.getAttribute('href'),target:el.getAttribute('target'),rel:el.getAttribute('rel')}))")
    page.get_by_role('button',name='Próximo',exact=True).focus()
    page.keyboard.press('Tab')
    def focus_card():
        return page.evaluate('''()=>{const a=document.activeElement,c=a.parentElement?.parentElement,r=a.getBoundingClientRect(),cr=c?.getBoundingClientRect(),s=getComputedStyle(a);return {tag:a.tagName,aria:a.getAttribute('aria-label'),cardIndex:[...document.querySelectorAll('a[aria-label^="Acessar página oficial:"]')].indexOf(a),focusVisible:a.matches(':focus-visible'),scrollLeft:c?.scrollLeft,rect:{x:r.x,y:r.y,width:r.width,height:r.height},container:cr?{x:cr.x,y:cr.y,width:cr.width,height:cr.height}:null,outline:s.outline,boxShadow:s.boxShadow,visibleHorizontally:cr? r.right>cr.left && r.left<cr.right:null}}''')
    results['card_focus_immediate']=focus_card()
    page.wait_for_timeout(600)
    results['card_focus_after_balance']=focus_card()
    page.screenshot(path=str(OUT/'card-focus-after-balance.png'))
    page.get_by_role('button',name='Alto contraste',exact=True).click()
    cards.nth(6).focus()
    results['high_contrast_card_focus']=cards.nth(6).evaluate("el=>{const s=getComputedStyle(el);return {outline:s.outline,boxShadow:s.boxShadow,color:s.color,background:s.backgroundColor}}")
    page.get_by_role('button',name='Gerenciamento de Cookies e Privacidade').click()
    results['modal_open']=page.locator('dialog').evaluate("el=>el.matches(':modal')")
    page.keyboard.press('Escape')
    results['modal_return_focus']=page.get_by_role('button',name='Gerenciamento de Cookies e Privacidade').evaluate('el=>el===document.activeElement')
    page.get_by_role('button',name='Alto contraste',exact=True).click()
    page.goto(BASE+'/',wait_until='domcontentloaded')
    page.locator('header').wait_for()
    plus=page.get_by_role('button',name='Aumentar tamanho da fonte',exact=True)
    results['toolbar_normal']=plus.evaluate("el=>{const s=getComputedStyle(el),r=el.getBoundingClientRect();return {fontSize:s.fontSize,width:r.width,height:r.height}}")
    plus.click()
    plus.click()
    results['toolbar_120']=plus.evaluate("el=>{const s=getComputedStyle(el),r=el.getBoundingClientRect();return {fontSize:s.fontSize,width:r.width,height:r.height,scale:document.documentElement.dataset.fontScale}}")
    results['reflow']=[]
    for width in [1280,640,390,320]:
        page.set_viewport_size({'width':width,'height':900})
        page.wait_for_timeout(250)
        results['reflow'].append(page.evaluate('''()=>{const hero=document.querySelector('[aria-label="Banner Principal"]'),cta=hero.querySelector('a.main-banner-cta'),hr=hero.getBoundingClientRect(),r=cta.getBoundingClientRect();return {viewport:innerWidth,scrollWidth:document.documentElement.scrollWidth,scale:document.documentElement.dataset.fontScale,hero:{top:hr.top,bottom:hr.bottom},cta:{x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom},ctaWithinHero:r.top>=hr.top&&r.bottom<=hr.bottom&&r.left>=hr.left&&r.right<=hr.right}}'''))
    page.screenshot(path=str(OUT/'home-320-font-120.png'),full_page=True)
    page.set_viewport_size({'width':1280,'height':900})
    page.get_by_role('button',name='Tamanho de fonte normal',exact=True).click()
    page.wait_for_timeout(5000)
    styles=page.locator('style').evaluate_all('els=>els.map(el=>el.textContent)')
    results['inline_styles']=[]
    for content in styles:
        digest='sha256-'+base64.b64encode(hashlib.sha256(content.encode()).digest()).decode()
        results['inline_styles'].append({'hash':digest,'length':len(content),'sample':content[:240]})
    OUT.joinpath('frontend-evidence.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    print(json.dumps(results,ensure_ascii=False,indent=2))
    browser.close()
