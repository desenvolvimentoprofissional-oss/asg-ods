from pathlib import Path
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright
import sys,json,hashlib,base64

BASE=sys.argv[1].rstrip('/')
OUT=Path('/workspace/production-review-3baf58e/vlibras-evidence')
result={'commit':'3baf58e04238ca61a386a03e39e0932de430693a','base':BASE,'responses':[],'requestFailures':[],'pageErrors':[]}
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    context=browser.new_context(viewport={'width':1280,'height':900})
    context.add_init_script('window.__auditCspViolations=[];document.addEventListener("securitypolicyviolation",e=>window.__auditCspViolations.push({directive:e.effectiveDirective,blocked:e.blockedURI,source:e.sourceFile,line:e.lineNumber,sample:e.sample}));')
    def allow_required(route):
        host=urlsplit(route.request.url).hostname or ''
        if host in ('localhost','127.0.0.1','vlibras.gov.br','cdn.jsdelivr.net') or host.endswith('.vlibras.gov.br'):
            route.continue_()
        else:
            route.abort()
    context.route('**/*',allow_required)
    page=context.new_page()
    page.on('response',lambda r:result['responses'].append({'url':r.url,'status':r.status}) if 'vlibras' in r.url or 'jsdelivr' in r.url else None)
    page.on('requestfailed',lambda r:result['requestFailures'].append({'url':r.url,'failure':r.failure}))
    page.on('pageerror',lambda e:result['pageErrors'].append(str(e)))
    response=page.goto(BASE+'/',wait_until='domcontentloaded')
    result['responseStatus']=response.status
    result['actualCsp']=response.headers.get('content-security-policy')
    page.locator('h1').first.wait_for()
    page.locator('#vlibras-script').wait_for(state='attached')
    result['scriptTag']=page.locator('#vlibras-script').evaluate('(e)=>({src:e.src,integrity:e.integrity,crossOrigin:e.crossOrigin,dataVersion:e.getAttribute("data-version"),async:e.async})')
    page.wait_for_timeout(16500)
    result['runtime']=page.evaluate('({libraryPresent:!!window.VLibras,widgetConstructorPresent:typeof window.VLibras?.Widget==="function",wrapperPresent:!!document.getElementById("vlibras-access-wrapper"),statusText:Array.from(document.querySelectorAll("[vw] [role=status]")).map(e=>e.textContent.trim()),cspViolations:window.__auditCspViolations,styleHashesRequested:null})')
    result['nativeStyleElements']=[]
    for css in page.locator('style').all_text_contents():
        digest='sha256-'+base64.b64encode(hashlib.sha256(css.encode('utf8')).digest()).decode('ascii')
        result['nativeStyleElements'].append({'bytes':len(css.encode('utf8')),'hash':digest})
    browser.close()
(OUT/'runtime.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('actualCsp',)},indent=2,ensure_ascii=False))
