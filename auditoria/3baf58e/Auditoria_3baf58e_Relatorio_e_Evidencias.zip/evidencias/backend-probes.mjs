// NODE_ENV=test isolates this Express instance. No Firestore read/write or public request.
import fs from 'node:fs';
import request from '/workspace/asg-ods/node_modules/supertest/index.js';
if(process.env.NODE_ENV!=='test')throw new Error('NODE_ENV=test required');
const {app,rateLimitMap}=await import('/workspace/asg-ods/server.ts');
const {CSP_HEADER,DEV_CSP_HEADER}=await import('/workspace/asg-ods/src/server/securityHeaders.ts');
const firebase=JSON.parse(fs.readFileSync('/workspace/asg-ods/firebase.json','utf8'));
const hostingCsp=firebase.hosting.headers.flatMap(x=>x.headers).find(x=>x.key==='Content-Security-Policy').value;
const parse=s=>Object.fromEntries(s.split(';').map(x=>x.trim()).filter(Boolean).map(x=>{const[k,...v]=x.split(/\s+/);return[k,v];}));
const p=parse(CSP_HEADER),h=parse(hostingCsp);
const diffs=Object.keys(p).filter(k=>JSON.stringify(p[k])!==JSON.stringify(h[k])).map(k=>({directive:k,onlyExpress:p[k].filter(x=>!h[k]?.includes(x)),onlyHosting:(h[k]||[]).filter(x=>!p[k].includes(x))}));
const probes=[
 ['scalar','probe=one'],
 ['list',['probe1=one','probe2=two; Secure; SameSite=Strict; HttpOnly']],
 ['readonly',Object.freeze(['probe1=one','probe2=two'])],
 ['existing-none','probe=one; SameSite=None; Secure'],
];
for(const[name,value]of probes)app.get('/__backend_probe/'+name,(_req,res)=>{res.setHeader('Set-Cookie',value);res.setHeader('X-Probe-Number',7);res.json({probe:name});});
process.env.NODE_ENV='production';
const cookies=[];
for(const[name]of probes){const r=await request(app).get('/__backend_probe/'+name);cookies.push({name,status:r.status,cookies:r.headers['set-cookie'],numericHeader:r.headers['x-probe-number']});}
rateLimitMap.clear();
const invalid=await request(app).post('/api/registrar-interesse').send({});
console.log(JSON.stringify({sha:'3baf58e04238ca61a386a03e39e0932de430693a',firestoreOperations:0,productionOperations:0,cspDiffs:diffs,scriptDirectiveUnchanged:JSON.stringify(p['script-src'])===JSON.stringify(h['script-src']),productionAllowsArbitraryInlineStyles:p['style-src'].includes("'unsafe-inline'"),productionAllowsEval:p['script-src'].includes("'unsafe-eval'"),cookieProbes:cookies,invalidPost:{status:invalid.status,error:invalid.body.error,headers:{csp:invalid.headers['content-security-policy'],hsts:invalid.headers['strict-transport-security'],contentTypeOptions:invalid.headers['x-content-type-options'],referrerPolicy:invalid.headers['referrer-policy'],corp:invalid.headers['cross-origin-resource-policy'],coep:invalid.headers['cross-origin-embedder-policy'],coop:invalid.headers['cross-origin-opener-policy'],permissions:invalid.headers['permissions-policy'],xPoweredBy:invalid.headers['x-powered-by']||null}},devPolicySelectedSeparately:DEV_CSP_HEADER!==CSP_HEADER},null,2));
