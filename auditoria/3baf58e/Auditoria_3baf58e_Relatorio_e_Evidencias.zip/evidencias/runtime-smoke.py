from pathlib import Path
import urllib.request, urllib.error, re, json, hashlib, base64

root = Path('/workspace/production-review-3baf58e')
origin = 'http://127.0.0.1:3011'
results = {'commit': '3baf58e04238ca61a386a03e39e0932de430693a',
           'production_database_writes': 0, 'checks': [], 'sri': []}

def fetch(path, data=None):
    req = urllib.request.Request(origin + path, data=data,
        headers={'Content-Type': 'application/json'} if data is not None else {})
    try:
        response = urllib.request.urlopen(req, timeout=10)
    except urllib.error.HTTPError as error:
        response = error
    with response:
        return response.status, dict(response.headers), response.read()

for path in ['/', '/chancela', '/metodologia', '/trilha', '/registro-interesse',
             '/ai-catalog.json', '/.well-known/agent-card.json']:
    status, headers, content = fetch(path)
    expected = 404 if path == '/.well-known/agent-card.json' else 200
    results['checks'].append({'path': path, 'status': status, 'expected': expected,
                              'pass': status == expected})

status, headers, html = fetch('/')
csp = headers.get('Content-Security-Policy', '')
script_policy = next(p.strip() for p in csp.split(';') if p.strip().startswith('script-src '))
results['headers'] = {
    'csp': csp, 'script_policy_no_unsafe_inline_or_eval':
    'unsafe-inline' not in script_policy and 'unsafe-eval' not in script_policy,
    'nosniff': headers.get('X-Content-Type-Options') == 'nosniff',
    'no_referrer': headers.get('Referrer-Policy') == 'no-referrer',
    'hsts': headers.get('Strict-Transport-Security', ''),
    'x_powered_by_absent': 'X-Powered-By' not in headers,
}

for tag in re.findall(r'<(?:script|link)\b[^>]*>', html.decode()):
    url = re.search(r'(?:src|href)="(/assets/[^"]+)"', tag)
    integrity = re.search(r'integrity="([^"]+)"', tag)
    if not url:
        continue
    assert integrity, tag
    status, _, data = fetch(url.group(1))
    actual = 'sha384-' + base64.b64encode(hashlib.sha384(data).digest()).decode()
    results['sri'].append({'path': url.group(1), 'status': status,
                           'matches': actual == integrity.group(1)})

for path in ['/assets/nonexistent.js', '/api/nonexistent', '/api/registrar-interesse']:
    status, _, _ = fetch(path)
    results['checks'].append({'path': path, 'status': status, 'expected': 404,
                              'pass': status == 404})

for path in ['/server.ts', '/.env', '/.git/config', '/package.json', '/firestore.rules']:
    status, _, content = fetch(path)
    safe = status == 404 or (status == 200 and content == html)
    results['checks'].append({'path': path, 'status': status,
                              'returns_spa_or_404_without_source': safe, 'pass': safe})

for label, data, expected in [
    ('malformed_json', b'{', 400),
    ('invalid_schema', b'{"unexpected":"value"}', 400),
    ('oversize_json', json.dumps({'padding': 'x' * 16000}).encode(), 413),
]:
    status, _, content = fetch('/api/registrar-interesse', data)
    payload = json.loads(content)
    results['checks'].append({'case': label, 'status': status, 'expected': expected,
                              'error': payload.get('error'), 'pass': status == expected})

results['pass'] = (all(c['pass'] for c in results['checks'])
                   and all(c['matches'] and c['status'] == 200 for c in results['sri'])
                   and results['headers']['script_policy_no_unsafe_inline_or_eval']
                   and results['headers']['nosniff']
                   and results['headers']['x_powered_by_absent'])
(root / 'runtime-smoke.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
print(json.dumps({'pass': results['pass'], 'checks': len(results['checks']),
                  'sri_assets': len(results['sri']),
                  'failed': [c for c in results['checks'] if not c['pass']]}, indent=2))
assert results['pass']
